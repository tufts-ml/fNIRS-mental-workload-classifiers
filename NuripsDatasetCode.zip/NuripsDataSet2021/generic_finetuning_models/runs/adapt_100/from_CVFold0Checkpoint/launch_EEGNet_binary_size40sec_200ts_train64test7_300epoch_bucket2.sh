#!/bin/bash
#
# Usage
# -----
# $ bash launch_experiments.sh ACTION_NAME
#
# where ACTION_NAME is either 'list' or 'submit' or 'run_here'

if [[ -z $1 ]]; then
    ACTION_NAME='list'
else
    ACTION_NAME=$1
fi

export gpu_idx=0
export data_dir='/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/data/Leon/Visual/size_40sec_200ts_stride_3ts/'
export window_size=200
export classification_task='binary'
export cv_train_batch_size=243
export cv_val_batch_size=61
export test_batch_size=304
export n_epoch=300
export adapt_on='train_100'
export setting='train64test7_bucket2'
export result_save_rootdir="/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/experiments/generic_finetuning_models/EEGNet/binary/adapt_100/from_CVFold0Checkpoint/train64test7/bucket2/" 
export restore_file="/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/experiments/generic_models/EEGNet/binary/300epoch/train64test7_best_checkpoints/bucket2/EEGNet_fold0_best_model.statedict"


    
if [[ $ACTION_NAME == 'submit' ]]; then
    ## Use this line to submit the experiment to the batch scheduler
    sbatch < /cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/generic_finetuning_models/runs/do_experiment_EEGNet.slurm

elif [[ $ACTION_NAME == 'run_here' ]]; then
    ## Use this line to just run interactively
    bash /cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/generic_finetuning_models/runs/do_experiment_EEGNet.slurm
fi

