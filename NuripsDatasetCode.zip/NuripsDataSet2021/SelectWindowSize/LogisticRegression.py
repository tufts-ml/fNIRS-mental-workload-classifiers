import os
import sys
import numpy as np
import argparse

from easydict import EasyDict as edict
from tqdm import trange
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression

sys.path.insert(0, '../../helpers')
import models
import brain_data
from utils import seed_everything, featurize, makedir_if_not_exist, plot_confusion_matrix, save_pickle, ensemble_and_extract_performance

parser = argparse.ArgumentParser()
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--data_dir', default='../data/Leon/Visual/size_2sec_10ts_stride_3ts/', help='folder to the train data')
parser.add_argument('--SelectWindowSize_testset_dir', default='../data/UsedForSelectingWindowSize/Visual/size_2sec_10ts_stride_3ts', help='folder to the test data')
parser.add_argument('--window_size', default=10, type=int, help='window size')
parser.add_argument('--result_save_rootdir', default='./experiments', help='folder to the result')
parser.add_argument('--SubjectId_of_interest', default='1', help='which subject of interest')
parser.add_argument('--classification_task', default='four_class', help='binary or four-class classification')

def train_classifier(args_dict):
    
    #parse args:
    data_dir = args_dict.data_dir
    SelectWindowSize_testset_dir = args_dict.SelectWindowSize_testset_dir
    window_size = args_dict.window_size
    result_save_rootdir = args_dict.result_save_rootdir
    SubjectId_of_interest = args_dict.SubjectId_of_interest
    classification_task = args_dict.classification_task
    
    #load this subject's data
    sub_file = 'sub_{}.csv'.format(SubjectId_of_interest)
    
    if window_size == 10:
        num_chunk_this_window_size = 2224
    elif window_size == 25:
        num_chunk_this_window_size = 2144
    elif window_size == 50:
        num_chunk_this_window_size = 2016
    elif window_size == 100:
        num_chunk_this_window_size = 1744
    elif window_size == 150:
        num_chunk_this_window_size = 1472
    elif window_size == 200:
        num_chunk_this_window_size = 1216
    else:
        raise NameError('not supported window size')
        
    
    #sanity check:
    if classification_task == 'four_class':
        sub_feature_array, sub_label_array = brain_data.read_subject_csv(os.path.join(data_dir, sub_file), num_chunk_this_window_size=num_chunk_this_window_size)
        sub_test_feature_array, sub_test_label_array = brain_data.read_subject_csv_SelectWindowSize(os.path.join(SelectWindowSize_testset_dir, sub_file))
        
        sub_data_len = len(sub_label_array)
        confusion_matrix_figure_labels = ['0back', '1back', '2back', '3back']
        
        assert sub_data_len == num_chunk_this_window_size, 'subject {} len is not {} for four-class classificatioon'.format(SubjectId_of_interest, num_chunk_this_window_size)
        assert len(sub_test_label_array) == 608 
        
    elif classification_task == 'binary':
        sub_feature_array, sub_label_array = brain_data.read_subject_csv_binary(os.path.join(data_dir, sub_file), num_chunk_this_window_size=num_chunk_this_window_size)
        sub_test_feature_array, sub_test_label_array = brain_data.read_subject_csv_binary_SelectWindowSize(os.path.join(SelectWindowSize_testset_dir, sub_file))
        
        sub_data_len = len(sub_label_array)
        confusion_matrix_figure_labels = ['0back', '2back']
        
        assert sub_data_len == int(num_chunk_this_window_size/2), 'subject {} len is not {} for binary classification'.format(SubjectId_of_interest, int(num_chunk_this_window_size/2))
        assert len(sub_test_label_array) == 304
        
    else:
        raise NameError('not supported classification setting')
        
    #use first half as train, second half as test (four-class: 8 tasks for train, 8 tasks for test) (binary: 4 tasks for train, 4 tasks for test )
    half_sub_data_len = int(sub_data_len/2)
    print('half_sub_data_len: {}'.format(half_sub_data_len), flush=True)
    sub_train_feature_array = sub_feature_array[:half_sub_data_len]
    sub_train_label_array = sub_label_array[:half_sub_data_len]
    
#     sub_test_feature_array = sub_feature_array[half_sub_data_len:]
#     sub_test_label_array = sub_label_array[half_sub_data_len:]
    
    transformed_sub_train_feature_array = featurize(sub_train_feature_array, classification_task)
    transformed_sub_test_feature_array = featurize(sub_test_feature_array, classification_task)
    
    #cross validation
    Cs = np.logspace(-5,5,11)
    
    for C in Cs:
        experiment_name = 'C{}'.format(C)
        #derived args
        result_save_subjectdir = os.path.join(result_save_rootdir, SubjectId_of_interest, experiment_name)
        result_save_subject_checkpointdir = os.path.join(result_save_subjectdir, 'checkpoint')
        result_save_subject_predictionsdir = os.path.join(result_save_subjectdir, 'predictions')
        result_save_subject_resultanalysisdir = os.path.join(result_save_subjectdir, 'result_analysis')
        result_save_subject_trainingcurvedir = os.path.join(result_save_subjectdir, 'trainingcurve')

        makedir_if_not_exist(result_save_subjectdir)
        makedir_if_not_exist(result_save_subject_checkpointdir)
        makedir_if_not_exist(result_save_subject_predictionsdir)
        makedir_if_not_exist(result_save_subject_resultanalysisdir)
        makedir_if_not_exist(result_save_subject_trainingcurvedir)
    
        result_save_dict = dict()
        ensemble_result_save_dict = dict()
        
        #Kfold cross validation for this setting
        kf = KFold(n_splits=5, shuffle=False, random_state=1)
        for idx, (train_index, val_index) in enumerate(kf.split(sub_train_feature_array)):
            print('current fold: {}'.format(idx), flush=True)
            if classification_task == 'binary':
                if window_size == 200: 
                    if idx == 0:
                        train_index = train_index[15:] #exclude 66 chunks between intersection
                    elif idx == 1:
                        train_index = train_index[91:]
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:76],train_index[122:]))
                        val_index = val_index[:-31]
                    elif idx == 3:
                        train_index = train_index[:152]
                    elif idx == 4:
                        train_index = train_index[:-16]
                
                elif window_size == 150: 
                    if idx == 0:
                        train_index = train_index[18:] #exclude 49 chunks between intersection
                    elif idx == 1:
                        train_index = np.concatenate((train_index[:25],train_index[110:]))
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:99],train_index[197:]))
                    elif idx == 3:
                        train_index = np.concatenate((train_index[:184],train_index[271:]))
                    elif idx == 4:
                        train_index = train_index[:-19]
                
                elif window_size == 100: 
                    if idx == 0:
                        train_index = train_index[21:] #exclude 32 chunks between intersection
                    elif idx == 1:
                        train_index = np.concatenate((train_index[:56],train_index[120:]))
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:143],train_index[207:]))
                    elif idx == 3:
                        train_index = np.concatenate((train_index[:230],train_index[294:]))
                    elif idx == 4:
                        train_index = train_index[:-22]
                
                elif window_size == 50: 
                    if idx == 0:
                        train_index = train_index[16:] #exclude 16 chunks between intersection
                    elif idx == 1:
                        train_index = np.concatenate((train_index[:85],train_index[117:]))
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:186],train_index[218:]))
                    elif idx == 3:
                        train_index = np.concatenate((train_index[:287],train_index[319:]))
                    elif idx == 4:
                        train_index = train_index[:-16]
                
                elif window_size == 25: 
                    if idx == 0:
                        train_index = train_index[7:] #exclude 7 chunks between intersection
                    elif idx == 1:
                        train_index = np.concatenate((train_index[:101],train_index[115:]))
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:208],train_index[222:]))
                    elif idx == 3:
                        train_index = np.concatenate((train_index[:315],train_index[329:]))
                    elif idx == 4:
                        train_index = train_index[:-7]
                        
                elif window_size == 10: 
                    if idx == 0:
                        train_index = train_index[2:] #exclude 2 chunks between intersection
                    elif idx == 1:
                        train_index = np.concatenate((train_index[:110],train_index[114:]))
                    elif idx == 2:
                        train_index = np.concatenate((train_index[:221],train_index[225:]))
                    elif idx == 3:
                        train_index = np.concatenate((train_index[:332],train_index[336:]))
                    elif idx == 4:
                        train_index = train_index[:-2]
                else:
                    raise NameError('not supported window size')
                
#             elif classification_task == 'four_class':
#                 if window_size == 200: 
# #                     if idx == 0:
# # #                         train_index = train_index[67:] #exclude the 67 chunks (in the intersection of train and val)
# #                          val_index = val_index[:-67]
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:157],train_index[290:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:380],train_index[513:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:602],train_index[735:]))
# #                     elif idx == 4:
# #                         train_index = train_index[:-67]
                
#                 elif window_size == 150:
# #                     if idx == 0:
# #                         train_index = train_index[50:] #exclude 50 chunks (in the intersection of train and val)
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:174],train_index[273:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:397],train_index[496:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:619],train_index[718:]))
# #                     elif idx == 4:
#                         train_index = train_index[:-50]
                
#                 elif window_size == 100: 
# #                     if idx == 0:
# #                         train_index = train_index[33:] #exclude 33 chunks (in the intersection of train and val)
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:191],train_index[256:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:414],train_index[479:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:636],train_index[701:]))
# #                     elif idx == 4:
# #                         train_index = train_index[:-33]
                
#                 elif window_size == 50: 
# #                     if idx == 0:
# #                         train_index = train_index[17:] #exclude 17 chunks (in the intersection of train and val)
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:207],train_index[240:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:430],train_index[463:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:652],train_index[685:]))
# #                     elif idx == 4:
# #                         train_index = train_index[:-17]
                
#                 elif window_size == 25: 
# #                     if idx == 0:
# #                         train_index = train_index[8:] #exclude 8 chunks (in the intersection of train and val)
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:216],train_index[231:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:439],train_index[454:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:661],train_index[676:]))
# #                     elif idx == 4:
# #                         train_index = train_index[:-8]
                        
#                 elif window_size == 10: 
# #                     if idx == 0:
# #                         train_index = train_index[3:] #exclude the first 3 chunks (in the intersection of train and val)
# #                     elif idx == 1:
# #                         train_index = np.concatenate((train_index[:221],train_index[226:]))
# #                     elif idx == 2:
# #                         train_index = np.concatenate((train_index[:444],train_index[449:]))
# #                     elif idx == 3:
# #                         train_index = np.concatenate((train_index[:666],train_index[671:]))
# #                     elif idx == 4:
# #                         train_index = train_index[:-3]
#                 else:
#                     raise NameError('not supported window size')
            
            else:
                raise NameError('not supported classification setting') 
            
                        

            #remove potential overlapping
#             val_index = val_index[3:-3] #change this value if changed window size
        
#             print('train index: {}'.format(train_index))
#             print('val index: {}'.format(val_index))
            
            #dataset object
            sub_cv_train_feature_array = transformed_sub_train_feature_array[train_index]
            sub_cv_train_label_array = sub_train_label_array[train_index]
            
            sub_cv_val_feature_array = transformed_sub_train_feature_array[val_index]
            sub_cv_val_label_array = sub_train_label_array[val_index]
            
            #create Logistic Regression object
            model = LogisticRegression(C=C, random_state=0, max_iter=5000, solver='lbfgs').fit(sub_cv_train_feature_array, sub_cv_train_label_array)
            
            # val performance 
            val_accuracy = model.score(sub_cv_val_feature_array, sub_cv_val_label_array) * 100
            result_save_dict['fold{}_bestepoch_val_accuracy'.format(idx)] = val_accuracy
            
            # test performance
            test_accuracy = model.score(transformed_sub_test_feature_array, sub_test_label_array) * 100
            test_logits = model.predict_proba(transformed_sub_test_feature_array)
            test_class_predictions = test_logits.argmax(1)
            
            result_save_dict['fold{}_bestepoch_test_accuracy'.format(idx)] = test_accuracy
            result_save_dict['fold{}_bestepoch_test_logits'.format(idx)] = test_logits.copy()
            result_save_dict['fold{}_bestepoch_test_class_labels'.format(idx)] = sub_test_label_array.copy()
            
            
            plot_confusion_matrix(test_class_predictions, sub_test_label_array, confusion_matrix_figure_labels, result_save_subject_resultanalysisdir, 'fold{}_test_confusion_matrix.png'.format(idx))
        
        save_pickle(result_save_subject_predictionsdir, 'result_save_dict.pkl', result_save_dict)
        
        #perform result analysis for this hyper combo
        #ensemble of the 5 folds
        bagging_test_accuracy, bagging_test_predictions, bagging_test_logits = ensemble_and_extract_performance('NA', result_save_subject_predictionsdir, result_save_subject_resultanalysisdir, 'result_save_dict.pkl')
        
        ensemble_result_save_dict['ensemble_test_logits'] = bagging_test_logits
        ensemble_result_save_dict['ensemble_test_predictions'] = bagging_test_predictions
        ensemble_result_save_dict['true_labels'] = sub_test_label_array
        save_pickle(result_save_subject_predictionsdir, 'ensemble_result_save_dict.pkl', ensemble_result_save_dict)
        
        print('Sub:{}, C:{}, Ensembled test accuracy: {}'.format(SubjectId_of_interest, C, bagging_test_accuracy), flush=True)
        plot_confusion_matrix(bagging_test_predictions, sub_test_label_array, confusion_matrix_figure_labels, result_save_subject_resultanalysisdir, 'final_confusion_matrix.png'.format(idx))
    
    
if __name__=='__main__':
    
    #parse args
    args = parser.parse_args()
    
    seed = args.seed
    data_dir = args.data_dir
    SelectWindowSize_testset_dir = args.SelectWindowSize_testset_dir
    window_size = args.window_size
    result_save_rootdir = args.result_save_rootdir
    SubjectId_of_interest = args.SubjectId_of_interest
    classification_task = args.classification_task
    
    #sanity check 
    print('type(data_dir): {}'.format(type(data_dir)))
    print('type(SelectWindowSize_testset_dir): {}'.format(type(SelectWindowSize_testset_dir)))
    print('type(window_size): {}'.format(type(window_size)))
    print('type(SubjectId_of_interest): {}'.format(type(SubjectId_of_interest)))
    print('type(result_save_rootdir): {}'.format(type(result_save_rootdir)))
    print('type(classification_task): {}'.format(type(classification_task)))
    
    args_dict = edict()
    args_dict.data_dir = data_dir
    args_dict.SelectWindowSize_testset_dir = SelectWindowSize_testset_dir
    args_dict.window_size = window_size
    args_dict.result_save_rootdir = result_save_rootdir
    args_dict.SubjectId_of_interest = SubjectId_of_interest
    args_dict.classification_task = classification_task
    
    seed_everything(seed)
    train_classifier(args_dict)
        
            
            
            
            
    
    
    
    
    
    
    
    
    
    
    
    
    
    

