import os
import sys
import numpy as np
import torch
import torch.nn as nn

import argparse

from easydict import EasyDict as edict
from tqdm import trange

sys.path.insert(0, '/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/helpers')
import models
import brain_data
from utils import seed_everything, makedir_if_not_exist, plot_confusion_matrix, save_pickle, ensemble_and_extract_performance, train_one_epoch, eval_model, save_training_curves

from sklearn.model_selection import KFold

parser = argparse.ArgumentParser()
parser.add_argument('--seed', default=0, type=int, help="random seed")
parser.add_argument('--gpu_idx', default=0, type=int, help="gpu idx")
parser.add_argument('--data_dir', default='../data/Leon/Visual/size_40sec_200ts_stride_3ts/', help="folder to the dataset")
parser.add_argument('--window_size', default=200, type=int, help='window size')
parser.add_argument('--classification_task', default='four_class', help='binary or four-class classification')
parser.add_argument('--result_save_rootdir', default='/cluster/tufts/hugheslab/zhuang12/HCI/brain_data_processing-master/UIST/experiments', help="Directory containing the dataset")
parser.add_argument('--setting', default='train64test7_bucket1', help='which predefined train test split scenario')
parser.add_argument('--restore_file', default='None', help="xxx.statedict")

#fixed hyper for 40sec binary classification tasl
parser.add_argument('--cv_train_batch_size', default=243, type=int, help="cross validation train batch size")
parser.add_argument('--cv_val_batch_size', default=61, type=int, help="cross validation val batch size")
parser.add_argument('--test_batch_size', default=304, type=int, help="test batch size")
parser.add_argument('--n_epoch', default=500, type=int, help="number of epoch")

#hyper to search for 40sec binary classification
#hard coded into this script as for-loop
# parser.add_argument('--lr', default=0.01, type=float, help="learning rate")
# parser.add_argument('--dropout', default=0.2, type=float, help='dropout rate') #hz added Mar23 to give baseline more power


#for personal model, save the test prediction of each cv fold
def train_classifier(args_dict, train_subjects, test_subjects):
    
    #convert to string list
    train_subjects = [str(i) for i in train_subjects]
    test_subjects = [str(i) for i in test_subjects]
    
    #parse args:
    gpu_idx = args_dict.gpu_idx
    data_dir = args_dict.data_dir
    window_size = args_dict.window_size
    classification_task = args_dict.classification_task
    result_save_rootdir = args_dict.result_save_rootdir
#     setting = args_dict.setting  #does not need 'setting' inside train_classifier   
    restore_file = args_dict.restore_file
    
    cv_train_batch_size = args_dict.cv_train_batch_size 
    cv_val_batch_size = args_dict.cv_val_batch_size
    test_batch_size = args_dict.test_batch_size 
    n_epoch = args_dict.n_epoch
    
#     lr = args_dict.lr 
#     dropout = args_dict.dropout
    
    if window_size == 10:
        num_chunk_this_window_size = 2224
    elif window_size == 25:
        num_chunk_this_window_size = 2144
    elif window_size == 50:
        num_chunk_this_window_size = 2016
    elif window_size == 100:
        num_chunk_this_window_size = 1744
    elif window_size == 150:
        num_chunk_this_window_size = 1472
    elif window_size == 200:
        num_chunk_this_window_size = 1216
    else:
        raise NameError('not supported window size')
        
        
    if classification_task == 'four_class':
        data_loading_function = brain_data.read_subject_csv
        confusion_matrix_figure_labels = ['0back', '1back', '2back', '3back']
        
    elif classification_task == 'binary':
        data_loading_function = brain_data.read_subject_csv_binary
        confusion_matrix_figure_labels = ['0back', '2back']
        
    else:
        raise NameError('not supported classification type')
    
    
    #create the group data
    group_model_sub_train_feature_list = []
    group_model_sub_train_label_list = []
    
    for subject in train_subjects:
        sub_feature, sub_label = data_loading_function(os.path.join(data_dir, 'sub_{}.csv'.format(subject)),  num_chunk_this_window_size=num_chunk_this_window_size)
        
        group_model_sub_train_feature_list.append(sub_feature)
        group_model_sub_train_label_list.append(sub_label)
    
    group_model_sub_train_feature_array = np.concatenate(group_model_sub_train_feature_list, axis=0).astype(np.float32)
    group_model_sub_train_label_array = np.concatenate(group_model_sub_train_label_list, axis=0)
    
  
    #GPU setting
    cuda = torch.cuda.is_available()
    if cuda:
        print('Detected GPUs', flush = True)
        device = torch.device('cuda')
#         device = torch.device('cuda:{}'.format(gpu_idx))
    else:
        print('DID NOT detect GPUs', flush = True)
        device = torch.device('cpu')
        

    #cross validation:
    lrs = [0.01, 0.1, 1.0, 10.0]
    dropouts = [0.25, 0.5, 0.75]
    
    for lr in lrs:
        for dropout in dropouts:
            experiment_name = 'lr{}_dropout{}'.format(lr, dropout)#experiment name: used for indicating hyper setting

            #create test subjects dict
            test_subjects_dict = dict()
            for test_subject in test_subjects:
                
                #Mar21: Control: Do not rerun already finished experiment:
                #(if the result_analysis/performance.txt already exist, meaning this experiment has already finished previously)
                AlreadyFinished = os.path.exists(os.path.join(result_save_rootdir, test_subject, experiment_name, 'result_analysis', 'performance.txt'))
                if AlreadyFinished:
                    print('{}, lr:{} dropout:{} already finished, Do Not Rerun, continue to next setting'.format(SubjectId_of_interest, lr, dropout), flush = True)
                    continue

                
                #load this subject's test data
                sub_feature_array, sub_label_array = data_loading_function(os.path.join(data_dir, 'sub_{}.csv'.format(test_subject)), num_chunk_this_window_size=num_chunk_this_window_size)
                
                sub_data_len = len(sub_label_array)
                assert sub_data_len == int(num_chunk_this_window_size/2), 'subject {} len is not {} for binary classification'.format(SubjectId_of_interest, int(num_chunk_this_window_size/2))
                half_sub_data_len = int(sub_data_len/2)
                print('half_sub_data_len: {}'.format(half_sub_data_len), flush=True)
                
                sub_test_feature_array = sub_feature_array[half_sub_data_len:]
                sub_test_label_array = sub_label_array[half_sub_data_len:]
                
                #convert subject's test data into dataset object
                sub_test_set = brain_data.brain_dataset(sub_test_feature_array, sub_test_label_array)

                #convert subject's test dataset object into dataloader object
                sub_test_loader = torch.utils.data.DataLoader(sub_test_set, batch_size=test_batch_size, shuffle=False)
                
                #create the dict for this subject: 
                #each subject's dict has: 'sub_test_loader', 'sub_test_label_array',
                                        # 'resutl_save_subjectdir', 'resutl_save_subject_checkpointdir', 
                                        # 'result_save_subject_predictiondir', 'result_save_subject_resultanalysisdir'
                                        # 'result_save_subject_trainingcurvedir', 'result_save_dir', 'ensemble_result_save_dict'
                
                test_subjects_dict[test_subject] = dict()
                
                test_subjects_dict[test_subject]['sub_test_loader'] = sub_test_loader
                test_subjects_dict[test_subject]['sub_test_label_array'] = sub_test_label_array
                
                #derived args
                result_save_subjectdir = os.path.join(result_save_rootdir, test_subject, experiment_name)
                result_save_subject_checkpointdir = os.path.join(result_save_subjectdir, 'checkpoint')
                result_save_subject_predictionsdir = os.path.join(result_save_subjectdir, 'predictions')
                result_save_subject_resultanalysisdir = os.path.join(result_save_subjectdir, 'result_analysis')
                result_save_subject_trainingcurvedir = os.path.join(result_save_subjectdir, 'trainingcurve')
                
                makedir_if_not_exist(result_save_subjectdir)
                makedir_if_not_exist(result_save_subject_checkpointdir)
                makedir_if_not_exist(result_save_subject_predictionsdir)
                makedir_if_not_exist(result_save_subject_resultanalysisdir)
                makedir_if_not_exist(result_save_subject_trainingcurvedir)
                
                test_subjects_dict[test_subject]['result_save_subjectdir'] = result_save_subjectdir
                test_subjects_dict[test_subject]['result_save_subject_checkpointdir'] = result_save_subject_checkpointdir
                test_subjects_dict[test_subject]['result_save_subject_predictionsdir'] = result_save_subject_predictionsdir
                test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'] = result_save_subject_resultanalysisdir
                test_subjects_dict[test_subject]['result_save_subject_trainingcurvedir'] = result_save_subject_trainingcurvedir

                test_subjects_dict[test_subject]['result_save_dict'] = dict()
                test_subjects_dict[test_subject]['ensemble_result_save_dict'] = dict()
                
                
            
            #Kfold cross validation for this setting:
            kf = KFold(n_splits=5, shuffle=False, random_state=1)
            for idx, (train_index, val_index) in enumerate(kf.split(group_model_sub_train_feature_array)):
                print('current fold: {}'.format(idx), flush=True)
                
                if window_size == 200: 
                    if idx == 0:
                        train_index = train_index[66:] #max exclude 66 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-66]
                    else:
                        val_index = val_index[66:-66]

                elif window_size == 150: 
                    if idx == 0:
                        train_index = train_index[49:] #max exclude 49 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-49]
                    else:
                        val_index = val_index[49:-49]

                elif window_size == 100: 
                    if idx == 0:
                        train_index = train_index[32:] #max exclude 32 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-32]
                    else:
                        val_index = val_index[32:-32]

                elif window_size == 50: 
                    if idx == 0:
                        train_index = train_index[16:] #exclude 16 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-16]
                    else:
                        val_index = val_index[16:-16]

                elif window_size == 25: 
                    if idx == 0:
                        train_index = train_index[7:] #exclude 7 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-7]
                    else:
                        val_index = val_index[7:-7]

                elif window_size == 10: 
                    if idx == 0:
                        train_index = train_index[2:] #exclude 2 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-2]
                    else:
                        val_index = val_index[2:-2]

                else:
                    raise NameError('not supported window size')

                #dataset object
                sub_cv_train_set = brain_data.brain_dataset(group_model_sub_train_feature_array[train_index], group_model_sub_train_label_array[train_index])
                sub_cv_val_set = brain_data.brain_dataset(group_model_sub_train_feature_array[val_index], group_model_sub_train_label_array[val_index])

                #dataloader object
                sub_cv_train_loader = torch.utils.data.DataLoader(sub_cv_train_set, batch_size=cv_train_batch_size, shuffle=True) 
                sub_cv_val_loader = torch.utils.data.DataLoader(sub_cv_val_set, batch_size=cv_val_batch_size, shuffle=False)

                #create model
                model = models.EEGNet(dropout=dropout).to(device)

#                 #reload weights from restore_file is specified
#                 if restore_file != 'None':
#                     restore_path = os.path.join(os.path.join(result_save_subject_checkpointdir, restore_file))
#                     print('loading checkpoint: {}'.format(restore_path))
#                     model.load_state_dict(torch.load(restore_path, map_location=device))

                #create criterion and optimizer
                criterion = nn.NLLLoss() #for EEGNet and DeepConvNet, use nn.NLLLoss directly, which accept integer labels
                optimizer = torch.optim.Adam(model.parameters(), lr=lr) #the authors used Adam instead of SGD
                
                #training loop
                best_val_accuracy = 0.0

                epoch_train_loss = []
                epoch_validation_accuracy = []

                for epoch in trange(n_epoch, desc='5-fold cross validation'.format(idx)):
                    average_loss_this_epoch = train_one_epoch(model, optimizer, criterion, sub_cv_train_loader, device)
                    val_accuracy, _, _, _ = eval_model(model, sub_cv_val_loader, device)

                    epoch_train_loss.append(average_loss_this_epoch)
                    epoch_validation_accuracy.append(val_accuracy)

                    #update is_best flag
                    is_best = val_accuracy >= best_val_accuracy

                    if is_best:
                        best_val_accuracy = val_accuracy
                        
                        for test_subject in test_subjects:

                            torch.save(model.state_dict(), os.path.join(test_subjects_dict[test_subject]['result_save_subject_checkpointdir'], 'EEGNet_fold{}_best_model.statedict'.format(idx)))

                            #in the script use the name "logits" (what we mean in the code is score after log-softmax normalization) and "probabilities" interchangibly 
                            test_accuracy, test_class_predictions, test_class_labels, test_logits = eval_model(model, test_subjects_dict[test_subject]['sub_test_loader'], device)
                            print('test accuracy this fold for subject: {} is {}'.format(test_subject, test_accuracy))

                            test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_accuracy'.format(idx)] = test_accuracy
                            test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_val_accuracy'.format(idx)] = val_accuracy

                            test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_logits'.format(idx)] = test_logits.copy()
                            test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_class_predictions'.format(idx)] = test_class_predictions.copy()

                            test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_class_labels'.format(idx)] = test_class_labels.copy()


                for test_subject in test_subjects:
                    
                    #save training curve for each fold
                    save_training_curves('EEGNet_fold{}_training_curve.png'.format(idx), test_subjects_dict[test_subject]['result_save_subject_trainingcurvedir'], epoch_train_loss, epoch_validation_accuracy)

                    #confusion matrix for this fold
                    plot_confusion_matrix(test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_class_predictions'.format(idx)], test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_class_labels'.format(idx)], confusion_matrix_figure_labels, test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'fold{}_test_confusion_matrix.png'.format(idx))

                    #save the model at last epoch
                    torch.save(model.state_dict(), os.path.join(test_subjects_dict[test_subject]['result_save_subject_checkpointdir'], 'EEGNet_fold{}_last_model.statedict'.format(idx)))


            for test_subject in test_subjects:
                
                #save result_save_dict
                save_pickle(test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], 'result_save_dict.pkl', test_subjects_dict[test_subject]['result_save_dict'])


                #perform result analysis
                #ensemble of the 5 folds for ensembled test predictions
                bagging_test_accuracy, bagging_test_predictions, bagging_test_logits = ensemble_and_extract_performance(model.state_dict(), test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'result_save_dict.pkl')
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['ensemble_test_logits'] = bagging_test_logits
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['ensemble_test_predictions'] = bagging_test_predictions
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['true_labels'] = test_subjects_dict[test_subject]['sub_test_label_array']
                save_pickle(test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], 'ensemble_result_save_dict.pkl', test_subjects_dict[test_subject]['ensemble_result_save_dict'])

                print('Sub:{}, lr: {} dropout: {} Ensembled test accuracy is {}'.format(test_subject, lr, dropout, bagging_test_accuracy), flush=True)
                plot_confusion_matrix(bagging_test_predictions, test_subjects_dict[test_subject]['sub_test_label_array'], confusion_matrix_figure_labels, test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'final_confusion_matrix.png'.format(idx))



if __name__=='__main__':
    
    #parse args
    args = parser.parse_args()
    
    seed = args.seed
    gpu_idx = args.gpu_idx
    data_dir = args.data_dir
    window_size = args.window_size
    classification_task = args.classification_task
    result_save_rootdir = args.result_save_rootdir
    setting = args.setting
    restore_file = args.restore_file
    
    cv_train_batch_size = args.cv_train_batch_size
    cv_val_batch_size = args.cv_val_batch_size
    test_batch_size = args.test_batch_size
    n_epoch = args.n_epoch

    ###setting: (later improve the succinctness of the code by loading settings from json file)
    if setting == 'train64test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [56,  7,  5, 14, 60, 74, 55, 64, 79, 85, 73, 76, 69, 72, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 64, 79, 85, 73, 76, 69, 72, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 48, 47,
       63, 28, 78, 36, 97, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 48, 47,
       63, 28, 78, 36, 97, 38, 71, 44, 22, 82, 67, 23]
        
    elif setting == 'train32test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [48, 38, 34, 74, 63, 47, 31, 54, 29, 15, 81, 84, 32, 21, 85, 95, 78,
       58, 24, 60, 80, 20, 65, 92, 67, 51, 28, 76, 30, 86, 69,  5]
    elif setting == 'train32test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [81, 57, 75, 29, 78, 24, 22, 49, 46, 97, 36, 35, 47, 85, 25, 79, 20,
       71, 82, 76, 51, 54, 68, 52, 84, 48, 27, 43, 34, 92, 37, 91]
    elif setting == 'train32test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [45, 34, 32, 23, 67, 46, 83, 35, 56, 70, 43, 13, 24, 41, 38, 71, 61,
       27, 47, 15, 25, 74, 63,  5, 40, 62, 49, 31, 42, 97, 82, 29]
    elif setting == 'train32test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [78, 49, 72, 47, 45, 67, 44, 92, 71, 24,  7, 25, 82, 56, 31, 60, 30,
       22, 27, 28, 86, 35, 20, 63,  5, 74, 76, 34, 85, 84, 43, 70]
    elif setting == 'train32test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [64, 97, 60,  7, 51, 29, 20, 31, 57, 13, 14, 49, 73, 15, 46, 55, 69,
       85, 79, 94,  1, 28, 70, 75, 86, 93, 95, 84, 38, 72, 36, 91]
    elif setting == 'train32test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [82, 68, 40, 29, 69, 15, 61, 81, 45, 79, 75, 95, 56, 46, 28, 91, 70,
       67, 57, 35, 62,  5, 83, 47, 78, 38, 14, 52, 86, 64, 20, 43]
    elif setting == 'train32test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [47, 45, 76, 79, 57, 67,  5, 52, 75, 48, 41, 92, 70, 69, 46, 44, 55,
       86, 21, 28, 35, 61, 82, 97, 15, 95, 72, 40,  1, 58, 43, 25]
    elif setting == 'train32test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [93, 21, 71, 68, 81, 27, 30, 91, 23, 29, 13, 86, 41, 84, 72, 38, 60,
       51, 45, 40,  5, 42, 31, 56, 58, 82, 32,  7, 20, 80, 70, 52]
    elif setting == 'train32test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [24, 57, 85, 46, 45, 34,  1, 31,  7, 15, 58, 54, 75, 47, 91, 30, 79,
       60, 20, 93, 49, 78, 81, 36, 25, 48, 55, 72, 65, 35,  5, 61]
    elif setting == 'train32test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [14, 48, 20, 82, 69, 36, 78,  5, 32, 79, 81, 28, 41, 70, 71, 83, 27,
       93, 80, 61,  1, 44,  7, 31, 55, 65, 74, 72, 58, 67, 60, 97]
    
    elif setting == 'train16test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [32, 65, 15, 42, 97, 24, 78, 58, 13, 28, 69, 64, 29, 41, 40, 92]
    elif setting == 'train16test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [65, 44, 40, 47, 43, 29, 57, 58, 72, 35, 48, 41, 79, 45, 51, 61]
    elif setting == 'train16test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [7, 60,  5, 30, 15, 54, 41, 38, 36, 75, 32, 46, 97, 61, 83, 92]
    elif setting == 'train16test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [68, 23, 70, 34, 79, 49, 41, 92, 75, 85, 21, 97, 93, 51, 28, 82]
    elif setting == 'train16test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [92, 69, 72, 78, 47, 58, 76, 85, 94, 63, 49, 86, 34, 51, 65, 54]
    elif setting == 'train16test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [5, 61, 57, 85, 29, 81, 37, 43, 48, 49, 64, 75, 82, 72, 70, 21]
    elif setting == 'train16test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [28, 52, 14, 35, 22, 94, 29, 73, 57, 56, 32, 36, 41, 40, 15, 79]
    elif setting == 'train16test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [32, 29, 94, 25, 71, 22, 38, 56, 65, 62, 82, 81, 21, 42, 93,  7]
    elif setting == 'train16test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [36, 68, 27, 62, 79, 45, 13, 74, 73, 30, 78, 49, 21, 91, 25, 69]
    elif setting == 'train16test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [45, 83, 52, 70, 94, 60, 49, 79, 35, 72, 58, 55, 47, 73, 43, 28]
    
    elif setting == 'train8test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [35, 86,  7, 27, 47, 57, 81, 64]
    elif setting == 'train8test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [38, 79, 81, 80, 91, 85, 75, 97]
    elif setting == 'train8test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [32, 95, 34, 23, 31, 68, 35, 60]
    elif setting == 'train8test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [92, 31, 46,  1, 35, 83, 34, 47]
    elif setting == 'train8test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [95, 81, 42, 52, 55, 69, 68, 86]
    elif setting == 'train8test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [55, 52, 29, 24, 56, 60, 31, 28]
    elif setting == 'train8test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [14, 70, 64, 46, 35, 84, 91, 24]
    elif setting == 'train8test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [70, 49, 21, 91,  7, 20, 41, 80]
    elif setting == 'train8test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [55, 48, 83, 94, 70, 20, 57, 32]
    elif setting == 'train8test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [68,  7, 30, 42, 46,  1, 65, 69]
        
    elif setting == 'train4test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [15, 86, 24, 31]
    elif setting == 'train4test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [76, 38, 57, 75]
    elif setting == 'train4test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [27, 29, 78, 34]
    elif setting == 'train4test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [32, 34, 72,  7]
    elif setting == 'train4test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [36, 81, 84, 30]
    elif setting == 'train4test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [40, 78, 51,  5]
    elif setting == 'train4test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [94, 45, 97, 29]
    elif setting == 'train4test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [64, 93, 86, 44]
    elif setting == 'train4test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [54, 57, 21, 40]
    elif setting == 'train4test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [58, 79, 76, 68]
    
    elif setting == 'train2test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [40, 69]
    elif setting == 'train2test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [61, 63]
    elif setting == 'train2test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [95,  5]
    elif setting == 'train2test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [51, 97]
    elif setting == 'train2test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [85, 46]
    elif setting == 'train2test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [36, 83]
    elif setting == 'train2test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [79, 41]
    elif setting == 'train2test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [80, 79]
    elif setting == 'train2test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [1, 46]
    elif setting == 'train2test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [45, 71]
    
    else:
        raise NameError('not supported setting')
    
    #sanity check 
    print('data_dir: {} type: {}'.format(data_dir, type(data_dir)))
    print('window_size: {} type: {}'.format(window_size, type(window_size)))
    print('classification_task: {} type: {}'.format(classification_task, type(classification_task)))
    print('result_save_rootdir: {} type: {}'.format(result_save_rootdir, type(result_save_rootdir)))
    print('setting: {} type: {}'.format(setting, type(setting)))
    print('restore_file: {} type: {}'.format(restore_file, type(restore_file)))

    print('cv_train_batch_siz: {} type(cv_train_batch_size): {}'.format(cv_train_batch_size, type(cv_train_batch_size)))
    print('cv_val_batch_size: {} type(cv_val_batch_size): {}'.format(cv_val_batch_size, type(cv_val_batch_size)))
    print('test_batch_size: {} type(test_batch_size): {}'.format(test_batch_size, type(test_batch_size)))    
    print('n_epoch: {} type(n_epoch): {}'.format(n_epoch, type(n_epoch)))
    
    args_dict = edict() 
    
    args_dict.gpu_idx = gpu_idx
    args_dict.data_dir = data_dir
    args_dict.window_size = window_size
    args_dict.classification_task = classification_task
    args_dict.result_save_rootdir = result_save_rootdir
#     args_dict.setting = setting #does not need 'setting' inside train_classifier 
    args_dict.restore_file = restore_file
    
    args_dict.cv_train_batch_size = cv_train_batch_size
    args_dict.cv_val_batch_size = cv_val_batch_size
    args_dict.test_batch_size = test_batch_size
    args_dict.n_epoch = n_epoch

    
    
    seed_everything(seed)
    train_classifier(args_dict, train_subjects, test_subjects)
    
