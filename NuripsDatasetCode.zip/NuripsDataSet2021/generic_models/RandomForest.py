import os
import sys
import numpy as np
import argparse

from easydict import EasyDict as edict
from tqdm import trange
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier as rfc

sys.path.insert(0, '../../helpers')
import models
import brain_data
from utils import seed_everything, featurize, makedir_if_not_exist, plot_confusion_matrix, save_pickle, ensemble_and_extract_performance

parser = argparse.ArgumentParser()
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--data_dir', default='../data', help='folder to the data')
parser.add_argument('--window_size', default=10, type=int, help='window size')
parser.add_argument('--classification_task', default='four_class', help='binary or four-class classification')
parser.add_argument('--result_save_rootdir', default='./experiments', help='folder to the result')
parser.add_argument('--setting', default='train64test7_bucket1', help='which predefined train test split scenario')


def train_classifier(args_dict, train_subjects, test_subjects):
    
    #convert to string list
    train_subjects = [str(i) for i in train_subjects]
    test_subjects = [str(i) for i in test_subjects]
    
    #parse args:
    data_dir = args_dict.data_dir
    window_size = args_dict.window_size
    classification_task = args_dict.classification_task
    result_save_rootdir = args_dict.result_save_rootdir
#     setting = args_dict.setting  #does not need 'setting' inside train_classifier   
    
    if window_size == 10:
        num_chunk_this_window_size = 2224
    elif window_size == 25:
        num_chunk_this_window_size = 2144
    elif window_size == 50:
        num_chunk_this_window_size = 2016
    elif window_size == 100:
        num_chunk_this_window_size = 1744
    elif window_size == 150:
        num_chunk_this_window_size = 1472
    elif window_size == 200:
        num_chunk_this_window_size = 1216
    else:
        raise NameError('not supported window size')
        
    if classification_task == 'four_class':
        data_loading_function = brain_data.read_subject_csv
        confusion_matrix_figure_labels = ['0back', '1back', '2back', '3back']
        
    elif classification_task == 'binary':
        data_loading_function = brain_data.read_subject_csv_binary
        confusion_matrix_figure_labels = ['0back', '2back']
        
    else:
        raise NameError('not supported classification type')
        
        
    #create the group data
    group_model_sub_train_feature_list = []
    group_model_sub_train_label_list = []
    
    for subject in train_subjects:
        sub_feature, sub_label = data_loading_function(os.path.join(data_dir, 'sub_{}.csv'.format(subject)),  num_chunk_this_window_size=num_chunk_this_window_size)
        
        group_model_sub_train_feature_list.append(sub_feature)
        group_model_sub_train_label_list.append(sub_label)
    
    group_model_sub_train_feature_array = np.concatenate(group_model_sub_train_feature_list, axis=0).astype(np.float32)
    group_model_sub_train_label_array = np.concatenate(group_model_sub_train_label_list, axis=0)
    
    transformed_group_model_sub_train_feature_array = featurize(group_model_sub_train_feature_array, classification_task)
    
    
    #cross validation
    max_features_list = [0.166, 0.333, 0.667, 0.1]
    min_samples_leaf_list = [4, 16, 64]
    
    for max_features in max_features_list:
        for min_samples_leaf in min_samples_leaf_list:
            experiment_name = 'MaxFeatures{}_MinSamplesLeaf{}'.format(max_features, min_samples_leaf)
            
            #create test subjects dict
            test_subjects_dict = dict()
            for test_subject in test_subjects:
                #load this subject's test data
                sub_feature_array, sub_label_array = data_loading_function(os.path.join(data_dir, 'sub_{}.csv'.format(test_subject)), num_chunk_this_window_size=num_chunk_this_window_size)
            
                sub_data_len = len(sub_label_array)
                assert sub_data_len == int(num_chunk_this_window_size/2), 'subject {} len is not {} for binary classification'.format(SubjectId_of_interest, int(num_chunk_this_window_size/2))
                half_sub_data_len = int(sub_data_len/2)
                print('half_sub_data_len: {}'.format(half_sub_data_len), flush=True)
            
                sub_test_feature_array = sub_feature_array[half_sub_data_len:]
                transformed_sub_test_feature_array = featurize(sub_test_feature_array, classification_task)

                sub_test_label_array = sub_label_array[half_sub_data_len:]
            
                #create the dict for this subject: 
                #each subject's dict has: 'transformed_sub_test_feature_array', 'sub_test_label_array',
                                    # 'resutl_save_subjectdir', 'resutl_save_subject_checkpointdir', 
                                    # 'result_save_subject_predictiondir', 'result_save_subject_resultanalysisdir'
                                    # 'result_save_subject_trainingcurvedir', 'result_save_dir', 'ensemble_result_save_dict'
                            
                test_subjects_dict[test_subject] = dict()
                
                test_subjects_dict[test_subject]['transformed_sub_test_feature_array'] = transformed_sub_test_feature_array
                test_subjects_dict[test_subject]['sub_test_label_array'] = sub_test_label_array
            
                #derived args
                result_save_subjectdir = os.path.join(result_save_rootdir, test_subject, experiment_name)
                result_save_subject_checkpointdir = os.path.join(result_save_subjectdir, 'checkpoint')
                result_save_subject_predictionsdir = os.path.join(result_save_subjectdir, 'predictions')
                result_save_subject_resultanalysisdir = os.path.join(result_save_subjectdir, 'result_analysis')
                result_save_subject_trainingcurvedir = os.path.join(result_save_subjectdir, 'trainingcurve')

                makedir_if_not_exist(result_save_subjectdir)
                makedir_if_not_exist(result_save_subject_checkpointdir)
                makedir_if_not_exist(result_save_subject_predictionsdir)
                makedir_if_not_exist(result_save_subject_resultanalysisdir)
                makedir_if_not_exist(result_save_subject_trainingcurvedir)

                test_subjects_dict[test_subject]['result_save_subjectdir'] = result_save_subjectdir
                test_subjects_dict[test_subject]['result_save_subject_checkpointdir'] = result_save_subject_checkpointdir
                test_subjects_dict[test_subject]['result_save_subject_predictionsdir'] = result_save_subject_predictionsdir
                test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'] = result_save_subject_resultanalysisdir
                test_subjects_dict[test_subject]['result_save_subject_trainingcurvedir'] = result_save_subject_trainingcurvedir

                test_subjects_dict[test_subject]['result_save_dict'] = dict()
                test_subjects_dict[test_subject]['ensemble_result_save_dict'] = dict()
                
                
                
            #Kfold cross validation for this hyper combo
            kf = KFold(n_splits=5, shuffle=False, random_state=1)
            for idx, (train_index, val_index) in enumerate(kf.split(group_model_sub_train_feature_array)):
                print('current fold: {}'.format(idx), flush=True)
                if window_size == 200: 
                    if idx == 0:
                        train_index = train_index[66:] #max exclude 66 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-66]
                    else:
                        val_index = val_index[66:-66]

                elif window_size == 150: 
                    if idx == 0:
                        train_index = train_index[49:] #max exclude 49 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-49]
                    else:
                        val_index = val_index[49:-49]

                elif window_size == 100: 
                    if idx == 0:
                        train_index = train_index[32:] #max exclude 32 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-32]
                    else:
                        val_index = val_index[32:-32]

                elif window_size == 50: 
                    if idx == 0:
                        train_index = train_index[16:] #exclude 16 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-16]
                    else:
                        val_index = val_index[16:-16]

                elif window_size == 25: 
                    if idx == 0:
                        train_index = train_index[7:] #exclude 7 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-7]
                    else:
                        val_index = val_index[7:-7]

                elif window_size == 10: 
                    if idx == 0:
                        train_index = train_index[2:] #exclude 2 chunks between intersection
                    elif idx == 4:
                        train_index = train_index[:-2]
                    else:
                        val_index = val_index[2:-2]

                else:
                    raise NameError('not supported window size')
            

                #dataset object
                sub_cv_train_feature_array = transformed_group_model_sub_train_feature_array[train_index]
                sub_cv_train_label_array = group_model_sub_train_label_array[train_index]

                sub_cv_val_feature_array = transformed_group_model_sub_train_feature_array[val_index]
                sub_cv_val_label_array = group_model_sub_train_label_array[val_index]
            
                #create Logistic Regression object
                model = rfc(max_features=max_features, min_samples_leaf=min_samples_leaf).fit(sub_cv_train_feature_array, sub_cv_train_label_array)

                # val performance 
                val_accuracy = model.score(sub_cv_val_feature_array, sub_cv_val_label_array) * 100
                
                # test performance
                for test_subject in test_subjects:
                    test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_val_accuracy'.format(idx)] = val_accuracy

                    test_accuracy = model.score(test_subjects_dict[test_subject]['transformed_sub_test_feature_array'], test_subjects_dict[test_subject]['sub_test_label_array']) * 100
                    test_logits = model.predict_proba(test_subjects_dict[test_subject]['transformed_sub_test_feature_array'])
                    test_class_predictions = test_logits.argmax(1)

                    test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_accuracy'.format(idx)] = test_accuracy
                    test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_logits'.format(idx)] = test_logits
                    test_subjects_dict[test_subject]['result_save_dict']['fold{}_bestepoch_test_class_labels'.format(idx)] = test_subjects_dict[test_subject]['sub_test_label_array']


                    plot_confusion_matrix(test_class_predictions, test_subjects_dict[test_subject]['sub_test_label_array'], confusion_matrix_figure_labels, test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'fold{}_test_confusion_matrix.png'.format(idx))
                
            for test_subject in test_subjects:
                save_pickle(test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], 'result_save_dict.pkl', test_subjects_dict[test_subject]['result_save_dict'])
                
                #perform result analysis for this hyper combo
                #ensemble of the 5 folds
                bagging_test_accuracy, bagging_test_predictions, bagging_test_logits = ensemble_and_extract_performance('NA', test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'result_save_dict.pkl')
                
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['ensemble_test_logits'] = bagging_test_logits
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['ensemble_test_predictions'] = bagging_test_predictions
                test_subjects_dict[test_subject]['ensemble_result_save_dict']['true_labels'] = test_subjects_dict[test_subject]['sub_test_label_array']
                save_pickle(test_subjects_dict[test_subject]['result_save_subject_predictionsdir'], 'ensemble_result_save_dict.pkl', test_subjects_dict[test_subject]['ensemble_result_save_dict'])
                        
                print('Sub:{}, MaxFeature{}_MinSampleLeaf{}, Ensembled test accuracy: {}'.format(test_subject, max_features, min_samples_leaf, bagging_test_accuracy), flush=True)
                plot_confusion_matrix(bagging_test_predictions, test_subjects_dict[test_subject]['sub_test_label_array'], confusion_matrix_figure_labels, test_subjects_dict[test_subject]['result_save_subject_resultanalysisdir'], 'final_confusion_matrix.png'.format(idx))
                
                
    
if __name__=='__main__':
    
    #parse args
    args = parser.parse_args()
    
    seed = args.seed
    data_dir = args.data_dir
    window_size = args.window_size
    classification_task = args.classification_task
    result_save_rootdir = args.result_save_rootdir
    setting = args.setting

    ###setting: (later improve the succinctness of the code by loading settings from json file)
    if setting == 'train64test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [56,  7,  5, 14, 60, 74, 55, 64, 79, 85, 73, 76, 69, 72, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 64, 79, 85, 73, 76, 69, 72, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 54, 40, 81,
       15, 58, 52, 80, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 27, 32, 37, 61, 43, 24, 35,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80,  1, 92, 65, 84, 94, 30,
       41, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35, 51, 49, 62, 68, 42, 20, 31, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 48, 47, 63, 28, 78, 36, 97, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 38, 71,
       44, 22, 82, 67, 23, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 48, 47,
       63, 28, 78, 36, 97, 95, 13, 34, 86, 21, 25, 29, 57]
    elif setting == 'train64test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [91, 45, 93, 75, 46, 83, 70, 56,  7,  5, 14, 60, 74, 55, 64, 79, 85,
       73, 76, 69, 72, 54, 40, 81, 15, 58, 52, 80, 27, 32, 37, 61, 43, 24,
       35,  1, 92, 65, 84, 94, 30, 41, 51, 49, 62, 68, 42, 20, 31, 48, 47,
       63, 28, 78, 36, 97, 38, 71, 44, 22, 82, 67, 23]
    
    elif setting == 'train32test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [48, 38, 34, 74, 63, 47, 31, 54, 29, 15, 81, 84, 32, 21, 85, 95, 78,
       58, 24, 60, 80, 20, 65, 92, 67, 51, 28, 76, 30, 86, 69,  5]
    elif setting == 'train32test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [81, 57, 75, 29, 78, 24, 22, 49, 46, 97, 36, 35, 47, 85, 25, 79, 20,
       71, 82, 76, 51, 54, 68, 52, 84, 48, 27, 43, 34, 92, 37, 91]
    elif setting == 'train32test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [45, 34, 32, 23, 67, 46, 83, 35, 56, 70, 43, 13, 24, 41, 38, 71, 61,
       27, 47, 15, 25, 74, 63,  5, 40, 62, 49, 31, 42, 97, 82, 29]
    elif setting == 'train32test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [78, 49, 72, 47, 45, 67, 44, 92, 71, 24,  7, 25, 82, 56, 31, 60, 30,
       22, 27, 28, 86, 35, 20, 63,  5, 74, 76, 34, 85, 84, 43, 70]
    elif setting == 'train32test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [64, 97, 60,  7, 51, 29, 20, 31, 57, 13, 14, 49, 73, 15, 46, 55, 69,
       85, 79, 94,  1, 28, 70, 75, 86, 93, 95, 84, 38, 72, 36, 91]
    elif setting == 'train32test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [82, 68, 40, 29, 69, 15, 61, 81, 45, 79, 75, 95, 56, 46, 28, 91, 70,
       67, 57, 35, 62,  5, 83, 47, 78, 38, 14, 52, 86, 64, 20, 43]
    elif setting == 'train32test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [47, 45, 76, 79, 57, 67,  5, 52, 75, 48, 41, 92, 70, 69, 46, 44, 55,
       86, 21, 28, 35, 61, 82, 97, 15, 95, 72, 40,  1, 58, 43, 25]
    elif setting == 'train32test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [93, 21, 71, 68, 81, 27, 30, 91, 23, 29, 13, 86, 41, 84, 72, 38, 60,
       51, 45, 40,  5, 42, 31, 56, 58, 82, 32,  7, 20, 80, 70, 52]
    elif setting == 'train32test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [24, 57, 85, 46, 45, 34,  1, 31,  7, 15, 58, 54, 75, 47, 91, 30, 79,
       60, 20, 93, 49, 78, 81, 36, 25, 48, 55, 72, 65, 35,  5, 61]
    elif setting == 'train32test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [14, 48, 20, 82, 69, 36, 78,  5, 32, 79, 81, 28, 41, 70, 71, 83, 27,
       93, 80, 61,  1, 44,  7, 31, 55, 65, 74, 72, 58, 67, 60, 97]
    
    elif setting == 'train16test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [32, 65, 15, 42, 97, 24, 78, 58, 13, 28, 69, 64, 29, 41, 40, 92]
    elif setting == 'train16test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [65, 44, 40, 47, 43, 29, 57, 58, 72, 35, 48, 41, 79, 45, 51, 61]
    elif setting == 'train16test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [7, 60,  5, 30, 15, 54, 41, 38, 36, 75, 32, 46, 97, 61, 83, 92]
    elif setting == 'train16test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [68, 23, 70, 34, 79, 49, 41, 92, 75, 85, 21, 97, 93, 51, 28, 82]
    elif setting == 'train16test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [92, 69, 72, 78, 47, 58, 76, 85, 94, 63, 49, 86, 34, 51, 65, 54]
    elif setting == 'train16test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [5, 61, 57, 85, 29, 81, 37, 43, 48, 49, 64, 75, 82, 72, 70, 21]
    elif setting == 'train16test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [28, 52, 14, 35, 22, 94, 29, 73, 57, 56, 32, 36, 41, 40, 15, 79]
    elif setting == 'train16test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [32, 29, 94, 25, 71, 22, 38, 56, 65, 62, 82, 81, 21, 42, 93,  7]
    elif setting == 'train16test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [36, 68, 27, 62, 79, 45, 13, 74, 73, 30, 78, 49, 21, 91, 25, 69]
    elif setting == 'train16test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [45, 83, 52, 70, 94, 60, 49, 79, 35, 72, 58, 55, 47, 73, 43, 28]
        
    elif setting == 'train8test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [35, 86,  7, 27, 47, 57, 81, 64]
    elif setting == 'train8test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [38, 79, 81, 80, 91, 85, 75, 97]
    elif setting == 'train8test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [32, 95, 34, 23, 31, 68, 35, 60]
    elif setting == 'train8test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [92, 31, 46,  1, 35, 83, 34, 47]
    elif setting == 'train8test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [95, 81, 42, 52, 55, 69, 68, 86]
    elif setting == 'train8test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [55, 52, 29, 24, 56, 60, 31, 28]
    elif setting == 'train8test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [14, 70, 64, 46, 35, 84, 91, 24]
    elif setting == 'train8test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [70, 49, 21, 91,  7, 20, 41, 80]
    elif setting == 'train8test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [55, 48, 83, 94, 70, 20, 57, 32]
    elif setting == 'train8test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [68,  7, 30, 42, 46,  1, 65, 69]
        
    elif setting == 'train4test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [15, 86, 24, 31]
    elif setting == 'train4test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [76, 38, 57, 75]
    elif setting == 'train4test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [27, 29, 78, 34]
    elif setting == 'train4test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [32, 34, 72,  7]
    elif setting == 'train4test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [36, 81, 84, 30]
    elif setting == 'train4test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [40, 78, 51,  5]
    elif setting == 'train4test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [94, 45, 97, 29]
    elif setting == 'train4test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [64, 93, 86, 44]
    elif setting == 'train4test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [54, 57, 21, 40]
    elif setting == 'train4test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [58, 79, 76, 68]
    
    elif setting == 'train2test7_bucket1':
        test_subjects = [91, 45, 93, 75, 46, 83, 70]
        train_subjects = [40, 69]
    elif setting == 'train2test7_bucket2':
        test_subjects = [56,  7,  5, 14, 60, 74, 55]
        train_subjects = [61, 63]
    elif setting == 'train2test7_bucket3':
        test_subjects = [64, 79, 85, 73, 76, 69, 72]
        train_subjects = [95,  5]
    elif setting == 'train2test7_bucket4':
        test_subjects = [54, 40, 81, 15, 58, 52, 80]
        train_subjects = [51, 97]
    elif setting == 'train2test7_bucket5':
        test_subjects = [27, 32, 37, 61, 43, 24, 35]
        train_subjects = [85, 46]
    elif setting == 'train2test7_bucket6':
        test_subjects = [1, 92, 65, 84, 94, 30, 41]
        train_subjects = [36, 83]
    elif setting == 'train2test7_bucket7':
        test_subjects = [51, 49, 62, 68, 42, 20, 31]
        train_subjects = [79, 41]
    elif setting == 'train2test7_bucket8':
        test_subjects = [48, 47, 63, 28, 78, 36, 97]
        train_subjects = [80, 79]
    elif setting == 'train2test7_bucket9':
        test_subjects = [38, 71, 44, 22, 82, 67, 23]
        train_subjects = [1, 46]
    elif setting == 'train2test7_bucket10':
        test_subjects = [95, 13, 34, 86, 21, 25, 29, 57]
        train_subjects = [45, 71]
    
    else:
        raise NameError('not supported setting')
        
    
    #sanity check 
    print('data_dir: {} type: {}'.format(data_dir, type(data_dir)))
    print('window_size: {} type: {}'.format(window_size, type(window_size)))
    print('classification_task: {} type: {}'.format(classification_task, type(classification_task)))
    print('result_save_rootdir: {} type: {}'.format(result_save_rootdir, type(result_save_rootdir)))
    print('setting: {} type: {}'.format(setting, type(setting)))
    
    args_dict = edict()
    args_dict.data_dir = data_dir
    args_dict.window_size = window_size
    args_dict.classification_task = classification_task
    args_dict.result_save_rootdir = result_save_rootdir
#     args_dict.setting = setting #does not need 'setting' inside train_classifier 
    
    
    seed_everything(seed)
    train_classifier(args_dict, train_subjects, test_subjects)
        
            
            
            
            
    
    
    
    
    
    
    
    
    
    
    
    
    
    

