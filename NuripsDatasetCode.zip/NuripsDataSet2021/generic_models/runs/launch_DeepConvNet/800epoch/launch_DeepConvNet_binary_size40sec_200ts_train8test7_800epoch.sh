#!/bin/bash
#
# Usage
# -----
# $ bash launch_experiments.sh ACTION_NAME
#
# where ACTION_NAME is either 'list' or 'submit' or 'run_here'

if [[ -z $1 ]]; then
    ACTION_NAME='list'
else
    ACTION_NAME=$1
fi

export gpu_idx=0
export data_dir='/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/data/Leon/Visual/size_40sec_200ts_stride_3ts/'
export window_size=200
export classification_task='binary'
export restore_file='None'
export cv_train_batch_size=243
export cv_val_batch_size=61
export test_batch_size=304
export n_epoch=800

for setting in train8test7_bucket1 train8test7_bucket2 train8test7_bucket3 train8test7_bucket4 train8test7_bucket5 train8test7_bucket6 train8test7_bucket7 train8test7_bucket8 train8test7_bucket9 train8test7_bucket10
 
## NOTE all env vars that have been 'export'-ed will be passed along to the .slurm file
do
    export setting=$setting
    export result_save_rootdir="/cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/experiments/generic_models/DeepConvNet/binary/800epoch/$setting/" 
    
    if [[ $ACTION_NAME == 'submit' ]]; then
        ## Use this line to submit the experiment to the batch scheduler
        sbatch < /cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/generic_models/runs/do_experiment_DeepConvNet.slurm

    elif [[ $ACTION_NAME == 'run_here' ]]; then
        ## Use this line to just run interactively
        bash /cluster/tufts/hugheslab/zhuang12/HCI/NuripsDataSet2021/generic_models/runs/do_experiment_DeepConvNet.slurm
    fi
done

