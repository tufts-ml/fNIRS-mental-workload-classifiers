import os
import sys
import numpy as np
import torch
import torch.nn as nn

import argparse

from easydict import EasyDict as edict
from tqdm import trange

sys.path.insert(0, '../../helpers')
import models
import brain_data
from utils import seed_everything, makedir_if_not_exist, plot_confusion_matrix, save_pickle, ensemble_and_extract_performance, train_one_epoch, eval_model, save_training_curves

from sklearn.model_selection import KFold

parser = argparse.ArgumentParser()
parser.add_argument('--seed', default=0, type=int, help="random seed")
parser.add_argument('--gpu_idx', default=0, type=int, help="gpu idx")
parser.add_argument('--data_dir', default='../data/Leon/Visual/size_40sec_200ts_stride_3ts/', help="folder to the dataset")
parser.add_argument('--window_size', default=200, type=int, help='window size')
parser.add_argument('--result_save_rootdir', default='/cluster/tufts/hugheslab/zhuang12/HCI/brain_data_processing-master/UIST/experiments', help="Directory containing the dataset")
parser.add_argument('--SubjectId_of_interest', default='1', help="training personal model for which subject")
parser.add_argument('--classification_task', default='four_class', help='binary or four-class classification')
parser.add_argument('--restore_file', default='None', help="xxx.statedict")

#fixed hyper for 40sec binary classification tasl
parser.add_argument('--cv_train_batch_size', default=243, type=int, help="cross validation train batch size")
parser.add_argument('--cv_val_batch_size', default=61, type=int, help="cross validation val batch size")
parser.add_argument('--test_batch_size', default=304, type=int, help="test batch size")
parser.add_argument('--n_epoch', default=100, type=int, help="number of epoch")

#hyper to search for 40sec binary classification
#hard coded into this script as for-loop
# parser.add_argument('--lr', default=0.01, type=float, help="learning rate")
# parser.add_argument('--dropout', default=0.2, type=float, help='dropout rate') #hz added Mar23 to give baseline more power


#for personal model, save the test prediction of each cv fold
def train_classifier(args_dict):
    
    #parse args:
    gpu_idx = args_dict.gpu_idx
    data_dir = args_dict.data_dir
    window_size = args_dict.window_size
    result_save_rootdir = args_dict.result_save_rootdir
    SubjectId_of_interest = args_dict.SubjectId_of_interest
    classification_task = args_dict.classification_task
    restore_file = args_dict.restore_file
    
    cv_train_batch_size = args_dict.cv_train_batch_size 
    cv_val_batch_size = args_dict.cv_val_batch_size
    test_batch_size = args_dict.test_batch_size 
    n_epoch = args_dict.n_epoch
    
#     lr = args_dict.lr 
#     dropout = args_dict.dropout
    
    #load this subject's data
    sub_file = 'sub_{}.csv'.format(SubjectId_of_interest)
    
    if window_size == 10:
        num_chunk_this_window_size = 2224
    elif window_size == 25:
        num_chunk_this_window_size = 2144
    elif window_size == 50:
        num_chunk_this_window_size = 2016
    elif window_size == 100:
        num_chunk_this_window_size = 1744
    elif window_size == 150:
        num_chunk_this_window_size = 1472
    elif window_size == 200:
        num_chunk_this_window_size = 1216
    else:
        raise NameError('not supported window size')
        

    #sanity check:
    if classification_task == 'four_class':
        
        sub_feature_array, sub_label_array = brain_data.read_subject_csv(os.path.join(data_dir, sub_file), num_chunk_this_window_size=num_chunk_this_window_size)
        sub_data_len = len(sub_label_array)
        confusion_matrix_figure_labels = ['0back', '1back', '2back', '3back']
        
        assert sub_data_len == num_chunk_this_window_size, 'subject {} len is not {} for four-class classification'.format(SubjectId_of_interest, num_chunk_this_window_size)
        
    elif classification_task == 'binary':
        
        sub_feature_array, sub_label_array = brain_data.read_subject_csv_binary(os.path.join(data_dir, sub_file), num_chunk_this_window_size=num_chunk_this_window_size)
        sub_data_len = len(sub_label_array)
        confusion_matrix_figure_labels = ['0back', '2back']
        
        assert sub_data_len == int(num_chunk_this_window_size/2), 'subject {} len is not {} for binary classification'.format(SubjectId_of_interest, int(num_chunk_this_window_size/2))
        
    else:
        raise NameError('not supported classification setting')
    

    #use 1st half as train, 2nd half as test
    half_sub_data_len = int(sub_data_len/2)
    print('half_sub_data_len: {}'.format(half_sub_data_len), flush=True)
    
    sub_train_feature_array = sub_feature_array[:half_sub_data_len]
    sub_train_label_array = sub_label_array[:half_sub_data_len]

    sub_test_feature_array = sub_feature_array[half_sub_data_len:]
    sub_test_label_array = sub_label_array[half_sub_data_len:]

    #convert subject's test data into dataset object
    sub_test_set = brain_data.brain_dataset(sub_test_feature_array, sub_test_label_array)
    
    #convert subject's test dataset object into dataloader object
    sub_test_loader = torch.utils.data.DataLoader(sub_test_set, batch_size=test_batch_size, shuffle=False)
  
    #GPU setting
    cuda = torch.cuda.is_available()
    if cuda:
        print('Detected GPUs', flush = True)
        device = torch.device('cuda')
#         device = torch.device('cuda:{}'.format(gpu_idx))
    else:
        print('DID NOT detect GPUs', flush = True)
        device = torch.device('cpu')
        

    #cross validation:
    lrs = [0.01, 0.1, 1.0, 10.0]
    dropouts = [0.25, 0.5, 0.75]
    
    for lr in lrs:
        for dropout in dropouts:
            experiment_name = 'lr{}_dropout{}'.format(lr, dropout)#experiment name: used for indicating hyper setting

            #Mar21: Control: Do not rerun already finished experiment:
            #(if the result_analysis/performance.txt already exist, meaning this experiment has already finished previously)
            AlreadyFinished = os.path.exists(os.path.join(result_save_rootdir, SubjectId_of_interest, experiment_name, 'result_analysis', 'performance.txt'))
            if AlreadyFinished:
                print('{}, lr:{} dropout:{} already finished, Do Not Rerun, continue to next setting'.format(SubjectId_of_interest, lr, dropout), flush = True)
                continue

            #derived arg
            result_save_subjectdir = os.path.join(result_save_rootdir, SubjectId_of_interest, experiment_name)
            result_save_subject_checkpointdir = os.path.join(result_save_subjectdir, 'checkpoint')
            result_save_subject_predictionsdir = os.path.join(result_save_subjectdir, 'predictions')
            result_save_subject_resultanalysisdir = os.path.join(result_save_subjectdir, 'result_analysis')
            result_save_subject_trainingcurvedir = os.path.join(result_save_subjectdir, 'trainingcurve')

            makedir_if_not_exist(result_save_subjectdir)
            makedir_if_not_exist(result_save_subject_checkpointdir)
            makedir_if_not_exist(result_save_subject_predictionsdir)
            makedir_if_not_exist(result_save_subject_resultanalysisdir)
            makedir_if_not_exist(result_save_subject_trainingcurvedir)
            
            result_save_dict = dict()
            ensemble_result_save_dict = dict()
            
            #Kfold cross validation for this setting:
            kf = KFold(n_splits=5, shuffle=False, random_state=1)
            for idx, (train_index, val_index) in enumerate(kf.split(sub_train_feature_array)):
                if classification_task == 'binary':
                    if window_size == 200: 
                        if idx == 0:
                            train_index = train_index[15:] #exclude 66 chunks between intersection
                        elif idx == 1:
                            train_index = train_index[91:]
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:76],train_index[122:]))
                            val_index = val_index[:-31]
                        elif idx == 3:
                            train_index = train_index[:152]
                        elif idx == 4:
                            train_index = train_index[:-16]

                    elif window_size == 150: 
                        if idx == 0:
                            train_index = train_index[18:] #exclude 49 chunks between intersection
                        elif idx == 1:
                            train_index = np.concatenate((train_index[:25],train_index[110:]))
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:99],train_index[197:]))
                        elif idx == 3:
                            train_index = np.concatenate((train_index[:184],train_index[271:]))
                        elif idx == 4:
                            train_index = train_index[:-19]

                    elif window_size == 100: 
                        if idx == 0:
                            train_index = train_index[21:] #exclude 32 chunks between intersection
                        elif idx == 1:
                            train_index = np.concatenate((train_index[:56],train_index[120:]))
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:143],train_index[207:]))
                        elif idx == 3:
                            train_index = np.concatenate((train_index[:230],train_index[294:]))
                        elif idx == 4:
                            train_index = train_index[:-22]

                    elif window_size == 50: 
                        if idx == 0:
                            train_index = train_index[16:] #exclude 16 chunks between intersection
                        elif idx == 1:
                            train_index = np.concatenate((train_index[:85],train_index[117:]))
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:186],train_index[218:]))
                        elif idx == 3:
                            train_index = np.concatenate((train_index[:287],train_index[319:]))
                        elif idx == 4:
                            train_index = train_index[:-16]

                    elif window_size == 25: 
                        if idx == 0:
                            train_index = train_index[7:] #exclude 7 chunks between intersection
                        elif idx == 1:
                            train_index = np.concatenate((train_index[:101],train_index[115:]))
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:208],train_index[222:]))
                        elif idx == 3:
                            train_index = np.concatenate((train_index[:315],train_index[329:]))
                        elif idx == 4:
                            train_index = train_index[:-7]

                    elif window_size == 10: 
                        if idx == 0:
                            train_index = train_index[2:] #exclude 2 chunks between intersection
                        elif idx == 1:
                            train_index = np.concatenate((train_index[:110],train_index[114:]))
                        elif idx == 2:
                            train_index = np.concatenate((train_index[:221],train_index[225:]))
                        elif idx == 3:
                            train_index = np.concatenate((train_index[:332],train_index[336:]))
                        elif idx == 4:
                            train_index = train_index[:-2]
                    else:
                        raise NameError('not supported window size')
                
                elif classification_task == 'four_class':
                    raise NameError('four_class classification val index selection not implemented yet')
            
                else:
                    raise NameError('not supported classification setting') 

                #dataset object
                sub_cv_train_set = brain_data.brain_dataset(sub_train_feature_array[train_index], sub_train_label_array[train_index])
                sub_cv_val_set = brain_data.brain_dataset(sub_train_feature_array[val_index], sub_train_label_array[val_index])

                #dataloader object
                sub_cv_train_loader = torch.utils.data.DataLoader(sub_cv_train_set, batch_size=cv_train_batch_size, shuffle=True) 
                sub_cv_val_loader = torch.utils.data.DataLoader(sub_cv_val_set, batch_size=cv_val_batch_size, shuffle=False)

                #create model
                model = models.DeepConvNet(dropout=dropout).to(device)

                #reload weights from restore_file is specified
                if restore_file != 'None':
                    restore_path = os.path.join(os.path.join(result_save_subject_checkpointdir, restore_file))
                    print('loading checkpoint: {}'.format(restore_path))
                    model.load_state_dict(torch.load(restore_path, map_location=device))

                #create criterion and optimizer
                criterion = nn.NLLLoss() #for EEGNet and DeepConvNet, use nn.NLLLoss directly, which accept integer labels
                optimizer = torch.optim.Adam(model.parameters(), lr=lr) #the authors used Adam instead of SGD
                
                #training loop
                best_val_accuracy = 0.0

                epoch_train_loss = []
                epoch_validation_accuracy = []

                for epoch in trange(n_epoch, desc='5-fold cross validation'.format(idx)):
                    average_loss_this_epoch = train_one_epoch(model, optimizer, criterion, sub_cv_train_loader, device)
                    val_accuracy, _, _, _ = eval_model(model, sub_cv_val_loader, device)

                    epoch_train_loss.append(average_loss_this_epoch)
                    epoch_validation_accuracy.append(val_accuracy)

                    #update is_best flag
                    is_best = val_accuracy >= best_val_accuracy

                    if is_best:
                        best_val_accuracy = val_accuracy

                        torch.save(model.state_dict(), os.path.join(result_save_subject_checkpointdir, 'EEGNet_fold{}_best_model.statedict'.format(idx)))
                        
                        #in the script use the name "logits" (what we mean in the code is score after log-softmax normalization) and "probabilities" interchangibly 
                        test_accuracy, test_class_predictions, test_class_labels, test_logits = eval_model(model, sub_test_loader, device)
                        print('test accuracy for this fold is {}'.format(test_accuracy))

                        result_save_dict['fold{}_bestepoch_test_accuracy'.format(idx)] = test_accuracy
                        result_save_dict['fold{}_bestepoch_val_accuracy'.format(idx)] = val_accuracy

                        result_save_dict['fold{}_bestepoch_test_logits'.format(idx)] = test_logits.copy()
                        result_save_dict['fold{}_bestepoch_test_class_labels'.format(idx)] = test_class_labels.copy()


                #save training curve for each fold
                save_training_curves('EEGNet_fold{}_training_curve.png'.format(idx), result_save_subject_trainingcurvedir, epoch_train_loss, epoch_validation_accuracy)

                #confusion matrix for this fold
                plot_confusion_matrix(test_class_predictions, test_class_labels, confusion_matrix_figure_labels, result_save_subject_resultanalysisdir, 'fold{}_test_confusion_matrix.png'.format(idx))

                #save the model at last epoch
                torch.save(model.state_dict(), os.path.join(result_save_subject_checkpointdir, 'EEGNet_fold{}_last_model.statedict'.format(idx)))


            #save result_save_dict
            save_pickle(result_save_subject_predictionsdir, 'result_save_dict.pkl', result_save_dict)


            #perform result analysis
            #ensemble of the 5 folds for ensembled test predictions
            bagging_test_accuracy, bagging_test_predictions, bagging_test_logits = ensemble_and_extract_performance(model.state_dict(), result_save_subject_predictionsdir, result_save_subject_resultanalysisdir, 'result_save_dict.pkl')
            ensemble_result_save_dict['ensemble_test_logits'] = bagging_test_logits
            ensemble_result_save_dict['ensemble_test_predictions'] = bagging_test_predictions
            ensemble_result_save_dict['true_labels'] = sub_test_label_array
            save_pickle(result_save_subject_predictionsdir, 'ensemble_result_save_dict.pkl', ensemble_result_save_dict)
            
            print('Sub:{}, lr: {} dropout: {} Ensembled test accuracy is {}'.format(SubjectId_of_interest, lr, dropout, bagging_test_accuracy), flush=True)
            plot_confusion_matrix(bagging_test_predictions, sub_test_label_array, confusion_matrix_figure_labels, result_save_subject_resultanalysisdir, 'final_confusion_matrix.png'.format(idx))



if __name__=='__main__':
    
    #parse args
    args = parser.parse_args()
    
    seed = args.seed
    gpu_idx = args.gpu_idx
    data_dir = args.data_dir
    window_size = args.window_size
    result_save_rootdir = args.result_save_rootdir
    SubjectId_of_interest = args.SubjectId_of_interest
    classification_task = args.classification_task
    restore_file = args.restore_file
    
    cv_train_batch_size = args.cv_train_batch_size
    cv_val_batch_size = args.cv_val_batch_size
    test_batch_size = args.test_batch_size
    n_epoch = args.n_epoch

    
    #sanity check:
    print('type(data_dir): {}'.format(type(data_dir)))
    print('type(window_size): {}'.format(type(window_size)))
    print('type(result_save_rootdir): {}'.format(type(result_save_rootdir)))
    print('type(SubjectId_of_interest): {}'.format(type(SubjectId_of_interest)))
    print('type(classification_task): {}'.format(type(classification_task)))
    print('type(restore_file): {}'.format(type(restore_file)))
    print('type(cv_train_batch_size): {}'.format(type(cv_train_batch_size)))
    print('type(cv_val_batch_size): {}'.format(type(cv_val_batch_size)))
    print('type(test_batch_size): {}'.format(type(test_batch_size)))    
    print('type(n_epoch): {}'.format(type(n_epoch)))
       
    
    args_dict = edict() 
    
    args_dict.gpu_idx = gpu_idx
    args_dict.data_dir = data_dir
    args_dict.window_size = window_size
    args_dict.result_save_rootdir = result_save_rootdir
    args_dict.SubjectId_of_interest = SubjectId_of_interest
    args_dict.classification_task = classification_task
    args_dict.restore_file = restore_file
    args_dict.cv_train_batch_size = cv_train_batch_size
    args_dict.cv_val_batch_size = cv_val_batch_size
    args_dict.test_batch_size = test_batch_size
    args_dict.n_epoch = n_epoch

    
    
    seed_everything(seed)
    train_classifier(args_dict)
    
